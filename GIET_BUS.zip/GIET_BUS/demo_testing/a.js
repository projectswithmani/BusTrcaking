{
  "results": [
    {
      "address": "2 gunpur, Gunupur Bypass Rd, Gunupur, Odisha 765022, India",
      "postal_code": "765022",
      "country": "India",
      "region": "Odisha",
      "area": "Rayagada",
      "locality": "Gunupur",
      "street": "Gunupur Bypass Road",
      "location": {
        "lat": 19.068622,
        "lng": 83.814655
      },
      "location_type": "centroid",
      "type": "poi"
    },
    {
      "address": "3R97+HVC, Neeladri Vihar Lane 3, Gunupur, Odisha 765022, India",
      "postal_code": "765022",
      "country": "India",
      "region": "Odisha",
      "area": "Rayagada",
      "locality": "Gunupur",
      "street": "Neeladri Vihar Lane 3",
      "location": {
        "lat": 19.068898,
        "lng": 83.814614
      },
      "location_type": "exact",
      "type": "building"
    },
    {
      "address": "Maharshi Gurukul, lane4, Niladri Bihar, Gunupur, Odisha 765022, India",
      "postal_code": "765022",
      "country": "India",
      "region": "Odisha",
      "area": "Rayagada",
      "locality": "Gunupur",
      "sublocality": "Niladri Bihar",
      "location": {
        "lat": 19.067985,
        "lng": 83.814666
      },
      "location_type": "exact",
      "type": "street_address"
    },
    {
      "address": "3R97+FW Gunupur, Odisha, India",
      "postal_code": "765022",
      "country": "India",
      "region": "Odisha",
      "area": "Rayagada",
      "locality": "Gunupur",
      "location": {
        "lat": 19.068715,
        "lng": 83.814811
      },
      "location_type": "centroid",
      "type": "poi"
    },
    {
      "address": "Neeladri Vihar Lane 3, Gunupur, Odisha 765022, India",
      "postal_code": "765022",
      "country": "India",
      "region": "Odisha",
      "area": "Rayagada",
      "locality": "Gunupur",
      "street": "Neeladri Vihar Lane 3",
      "location": {
        "lat": 19.068723,
        "lng": 83.814663
      },
      "location_type": "centroid",
      "type": "route"
    }
  ]
}