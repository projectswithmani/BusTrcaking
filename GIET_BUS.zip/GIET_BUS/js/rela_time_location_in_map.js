
var f_longi=0,f_lati=0,l_lati=0,l_longi=0,h=0,m=0;
var time;
function loadDoc1() {
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        var result=this.responseText;
        var json = JSON.parse(result);
        var arr=json.feeds;
        var obj1=arr[0];
        f_longi=obj1.field1;
        f_lati=obj1.field2;
        var obj2=arr[1];
        l_longi=obj2.field1;
        l_lati=obj2.field2; 
        time=obj2.created_at; 
        var time = new Date(time);  
        // h=time.getHours();
        // m=time.getMinutes();
        // s=time.getSeconds();
        // var hours = (time.getHours() < 10 ? '0' : '') + time.getHours();
        // var minutes = (time.getMinutes() < 10 ? '0' : '') + time.getMinutes();
        // var div = document.getElementById('last_update');
        // div.innerHTML = hours + ":" + minutes+":" +s;
        var hours = time.getHours();
        var minutes = time.getMinutes();
        var newformat = hours >= 12 ? 'PM' : 'AM';         
        hours = hours % 12;     
        hours = hours ? hours : 12; 
        minutes = minutes < 10 ? '0' + minutes : minutes;        
        document.getElementById("last_update").innerHTML =hours + ':' + minutes + ' ' + newformat;
        
        // alert(h+":"+m+":"+s);
        // document.getElementById("last_update").innerHTML=h+":"+m+":"+s;
    }
    xhttp.open("GET", "https://api.thingspeak.com/channels/1853374/feeds.json?results=2");
    xhttp.send();
    }
    function insert_data(){
      loadDoc1();
      load();
  // var table = document.getElementById("myTable");
  // var row = table.insertRow(1);
  // var cell1 = row.insertCell(0);
  // var cell2 = row.insertCell(1);
  // var cell3 = row.insertCell(2);
  // var cell4 = row.insertCell(3);
  // cell1.innerHTML = 1;
  // cell2.innerHTML = 10;
  // cell3.innerHTML = l_lati;
  // cell4.innerHTML = h+":"+m+":"+s;

    }


    function map_new_page(){
      const xhttp = new XMLHttpRequest();
      xhttp.onload = function() {
        var result=this.responseText;
        var json = JSON.parse(result);
        var arr=json.feeds;
        var obj2=arr[1];
        l_longi=obj2.field1;
        l_lati=obj2.field2; 
        var url=`http://maps.google.com/maps?q=loc:${l_longi},${l_lati}`;
        window.open(url, '_blank');
        
    }
    xhttp.open("GET", "https://api.thingspeak.com/channels/1853374/feeds.json?results=2");
    xhttp.send();

      
    }
