var l_lati,l_longi;
function load() {
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        var result=this.responseText;
        var json = JSON.parse(result);
        var arr=json.feeds;
        // var obj1=arr[0];
        // f_longi=obj1.field1;
        // f_lati=obj1.field2;
        var obj2=arr[1];
        l_longi=obj2.field1;
        l_lati=obj2.field2; 
        get_location(l_lati,l_longi);
    }
    xhttp.open("GET", "https://api.thingspeak.com/channels/1853374/feeds.json?results=2");
    xhttp.send();
    }
function get_location(l_lati,l_longi){
        alert(l_lati+l_longi);
        const data = null;
        const xhr = new XMLHttpRequest();
        xhr.withCredentials = true;
        xhr.addEventListener("readystatechange", function () {
            if (this.readyState === this.DONE) {
                
                console.log(this.responseText);
                var result=this.responseText;
                var json = JSON.parse(result);
                var arr=json.results;
                var sub_obj=arr[0];
                document.getElementById("loc").innerHTML=sub_obj.street;
                
            }
        });
 
        var url="https://trueway-geocoding.p.rapidapi.com/ReverseGeocode?location="+l_longi+"%2C"+l_lati+"&language=en";
        alert(url);
        xhr.open("GET",url);
        xhr.setRequestHeader("X-RapidAPI-Key", "8e1ace4255msh89a61ce33da2b1bp1f5409jsnd3fa88903b7b");
        xhr.setRequestHeader("X-RapidAPI-Host", "trueway-geocoding.p.rapidapi.com");

        xhr.send(data);
        }